(async function(config) {
  'use strict';
  const root = new URL('.', document.baseURI);
  const blobs = [];
  const pending = new Map();
  const queue = [];
  const cancelLoads = new Set();
  let failure = null;
  let clearResources = () => {};
  let active = 0, loaded = 0;
  const total = Object.values(config.records).reduce((sum, file) => sum + file.size, 0);
  const checksum = async bytes => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), byte => byte.toString(16).padStart(2, '0')).join('');
  const fail = error => {
    if (failure) return;
    failure = error;
    for (const job of queue.splice(0)) job.reject(error);
    for (const cancel of Array.from(cancelLoads)) cancel(error);
    clearResources();
    release();
    console.error(error);
    window.doraSetState('faulted', error.message || String(error));
  };
  const release = () => { for (const url of blobs) URL.revokeObjectURL(url); blobs.length = 0; };
  window.addEventListener('pagehide', event => { if (!event.persisted) { clearResources(); release(); } });
  function pump() {
    while (!failure && active < 4 && queue.length) {
      const {name, resolve, reject} = queue.shift();
      const record = config.records[name];
      const script = document.createElement('script');
      active++;
      let delivered = false, finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        script.remove();
        pending.delete(name);
        cancelLoads.delete(cancel);
        active--;
        pump();
      };
      const cancel = error => { reject(error); finish(); };
      const timer = setTimeout(() => { reject(new Error('Timed out loading ' + record.script)); finish(); }, 120000);
      cancelLoads.add(cancel);
      pending.set(name, encoded => {
        if (delivered) return;
        delivered = true;
        (async () => {
          const raw = atob(encoded);
          if (raw.length !== record.size) throw new Error('HTML asset size mismatch: ' + name);
          const bytes = new Uint8Array(raw.length);
          for (let index = 0; index < raw.length; index++) bytes[index] = raw.charCodeAt(index);
          if (await checksum(bytes) !== record.sha256) throw new Error('HTML asset checksum mismatch: ' + name);
          if (failure) return;
          loaded += bytes.length;
          window.doraSetProgress(0.5 * loaded / total, 'Loading game resources…');
          resolve(bytes);
        })().catch(reject).finally(finish);
      });
      script.onload = () => { if (!delivered) { reject(new Error('Invalid HTML asset: ' + record.script)); finish(); } };
      script.onerror = () => { reject(new Error('Unable to load ' + record.script + '. Extract the entire ZIP before opening index.html.')); finish(); };
      script.src = new URL(record.script, root).href;
      document.body.appendChild(script);
    }
  }
  function read(name) {
    if (failure) return Promise.reject(failure);
    if (!Object.hasOwn(config.records, name)) return Promise.reject(new Error('Unknown HTML asset: ' + name));
    return new Promise((resolve, reject) => { queue.push({name, resolve, reject}); pump(); });
  }
  window.DoraHtmlPackage = Object.freeze({deliver: (name, encoded) => pending.get(name)?.(encoded)});
  try {
    if (!window.WebAssembly || !window.crypto?.subtle) throw new Error('Please use a modern browser with WebAssembly and Web Crypto support.');
    const names = Object.keys(config.records);
    const values = await Promise.all(names.map(read));
    const files = new Map(names.map((name, index) => [name, values[index]]));
    delete window.DoraHtmlPackage;
    let preload = files.get('dora-player-runtime.data').buffer;
    clearResources = () => {
      preload = null;
      delete Module.doraSnapshot;
      delete Module.wasmBinary;
      delete Module.getPreloadedPackage;
      files.clear();
      values.length = 0;
    };
    Module.wasmBinary = files.get('dora-player-runtime.wasm');
    Module.getPreloadedPackage = () => { const bytes = preload; preload = null; return bytes; };
    Module.doraSnapshot = {manifest: config.manifest, files: config.manifest.files.map(file => ({path: file.path, bytes: files.get(decodeURIComponent(file.url))}))};
    // file:// pages share an opaque origin: isolate saves by package directory.
    Module.doraStorageId = 'html-' + await checksum(new TextEncoder().encode(root.href));
    const audio = new Map();
    for (const [name, type] of [['dora-audio-mixer.wasm', 'application/wasm'], ['audio-worklet.js', 'text/javascript']]) {
      // A worklet module fetched from blob:null is rejected by Chromium on file://.
      // A data URL can be imported by the worklet without an origin or disk fetch.
      if (name === 'audio-worklet.js') {
        let source = '';
        for (const byte of files.get(name)) source += String.fromCharCode(byte);
        audio.set(name, 'data:text/javascript;base64,' + btoa(source));
        continue;
      }
      const url = URL.createObjectURL(new Blob([files.get(name)], {type}));
      audio.set(name, url);
      blobs.push(url);
    }
    Module.locateFile = (name, prefix = '') => audio.get(name) || new URL(name, prefix || root).href;
    const initialized = Module.onRuntimeInitialized;
    Module.onRuntimeInitialized = function() {
      clearResources();
      initialized?.();
    };
    const aborted = Module.onAbort;
    Module.onAbort = function(reason) {
      fail(new Error(String(reason || 'Runtime aborted')));
      aborted?.(reason);
    };
    const script = document.createElement('script');
    script.src = new URL('dora-player-runtime.js', root).href;
    script.onerror = () => fail(new Error('Unable to load the engine. Extract the entire ZIP before opening index.html.'));
    document.body.appendChild(script);
  } catch (error) { fail(error); }
})({"manifest":{"format":"dora-web-game","version":1,"engineVersion":"1.9.3","profile":"dora-preset","entry":"init.lua","files":[{"path":"Audio/tank_death.wav","url":"assets/d48d4b3fa336605fe42267b7f0c53951229b46d03371047d8955a49d61555a32/Audio/tank_death.wav","size":100844,"sha256":"d48d4b3fa336605fe42267b7f0c53951229b46d03371047d8955a49d61555a32","startup":true},{"path":"Audio/tank_fire.wav","url":"assets/89d03cc55dd427e8d75ace7fa7d5b823f624d1dac20e51f86f059485262b4347/Audio/tank_fire.wav","size":88244,"sha256":"89d03cc55dd427e8d75ace7fa7d5b823f624d1dac20e51f86f059485262b4347","startup":true},{"path":"Music/TankCues.lua","url":"assets/d191b28e2e9e5f14cddb8e4f5d1c51db84189a3c0954ea416484c338356bbf8b/Music/TankCues.lua","size":1046,"sha256":"d191b28e2e9e5f14cddb8e4f5d1c51db84189a3c0954ea416484c338356bbf8b","startup":true},{"path":"Music/TankCues.ts","url":"assets/0020bf0601a20a8668a29ef35728adb89f36d5735775b9681d6cf1773fcb6f78/Music/TankCues.ts","size":1070,"sha256":"0020bf0601a20a8668a29ef35728adb89f36d5735775b9681d6cf1773fcb6f78","startup":true},{"path":"init.lua","url":"assets/9673c9a06367ad4af72b35743a554595e3aef395d266b55d071eaf3a9390d7c5/init.lua","size":71086,"sha256":"9673c9a06367ad4af72b35743a554595e3aef395d266b55d071eaf3a9390d7c5","startup":true},{"path":"init.ts","url":"assets/928ef6032b7e2d909c09ff1b5c167fa2b3fa8a9bf0e835233f442c6099d33995/init.ts","size":50609,"sha256":"928ef6032b7e2d909c09ff1b5c167fa2b3fa8a9bf0e835233f442c6099d33995","startup":true},{"path":"tests/p01.lua","url":"assets/e8a3ca6f0120c908a7b1aa3151ec8e447c590069785176f9d1d73ca7b079eb20/tests/p01.lua","size":708,"sha256":"e8a3ca6f0120c908a7b1aa3151ec8e447c590069785176f9d1d73ca7b079eb20","startup":true},{"path":"tests/p01.ts","url":"assets/671da30bd24504d2c57499094b64e67f830d4e286a9616316733a90692997938/tests/p01.ts","size":388,"sha256":"671da30bd24504d2c57499094b64e67f830d4e286a9616316733a90692997938","startup":true}]},"records":{"dora-player-runtime.wasm":{"script":"html-assets/0.js","size":12954046,"sha256":"8cc31e2eeab206b01ce987967f6dfa367152444d8d5dd6404b58bcf1644a422a"},"dora-player-runtime.data":{"script":"html-assets/1.js","size":16902659,"sha256":"fe50cba2d69b78d41a06cc5a90970f34e64c02e4c68d04920b6066b918292d17"},"dora-audio-mixer.wasm":{"script":"html-assets/2.js","size":257583,"sha256":"77bc80abff5b7da9d8b70e82f0204542c6461616cb4a35f22ed8263e60d92329"},"audio-worklet.js":{"script":"html-assets/3.js","size":4811,"sha256":"0a69374be7060caf6651b1335b418df062345d4666d36f8d4638b06b2a97c76b"},"assets/d48d4b3fa336605fe42267b7f0c53951229b46d03371047d8955a49d61555a32/Audio/tank_death.wav":{"script":"html-assets/4.js","size":100844,"sha256":"d48d4b3fa336605fe42267b7f0c53951229b46d03371047d8955a49d61555a32"},"assets/89d03cc55dd427e8d75ace7fa7d5b823f624d1dac20e51f86f059485262b4347/Audio/tank_fire.wav":{"script":"html-assets/5.js","size":88244,"sha256":"89d03cc55dd427e8d75ace7fa7d5b823f624d1dac20e51f86f059485262b4347"},"assets/d191b28e2e9e5f14cddb8e4f5d1c51db84189a3c0954ea416484c338356bbf8b/Music/TankCues.lua":{"script":"html-assets/6.js","size":1046,"sha256":"d191b28e2e9e5f14cddb8e4f5d1c51db84189a3c0954ea416484c338356bbf8b"},"assets/0020bf0601a20a8668a29ef35728adb89f36d5735775b9681d6cf1773fcb6f78/Music/TankCues.ts":{"script":"html-assets/7.js","size":1070,"sha256":"0020bf0601a20a8668a29ef35728adb89f36d5735775b9681d6cf1773fcb6f78"},"assets/9673c9a06367ad4af72b35743a554595e3aef395d266b55d071eaf3a9390d7c5/init.lua":{"script":"html-assets/8.js","size":71086,"sha256":"9673c9a06367ad4af72b35743a554595e3aef395d266b55d071eaf3a9390d7c5"},"assets/928ef6032b7e2d909c09ff1b5c167fa2b3fa8a9bf0e835233f442c6099d33995/init.ts":{"script":"html-assets/9.js","size":50609,"sha256":"928ef6032b7e2d909c09ff1b5c167fa2b3fa8a9bf0e835233f442c6099d33995"},"assets/e8a3ca6f0120c908a7b1aa3151ec8e447c590069785176f9d1d73ca7b079eb20/tests/p01.lua":{"script":"html-assets/10.js","size":708,"sha256":"e8a3ca6f0120c908a7b1aa3151ec8e447c590069785176f9d1d73ca7b079eb20"},"assets/671da30bd24504d2c57499094b64e67f830d4e286a9616316733a90692997938/tests/p01.ts":{"script":"html-assets/11.js","size":388,"sha256":"671da30bd24504d2c57499094b64e67f830d4e286a9616316733a90692997938"}}});
