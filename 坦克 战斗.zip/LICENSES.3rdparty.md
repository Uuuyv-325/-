# Thirdparty Licenses Notice

Please note we provide an open source software notice for the third party open source software along with this software and/or this software component (in the following just “this SOFTWARE”). The open source software licenses are granted by the respective right holders.

Warranty Disclaimer

THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.



## Copyright Notice and License Texts

- [bgfx](https://github.com/bkaradzic/bgfx): [BSD-2 License](Source/3rdParty/bgfx/LICENSE)
- [blip-buf](http://www.slack.net/~ant/): [LGPL License](Source/3rdParty/tic80/vendor/blip-buf/license.txt)
- [colib](https://github.com/colinsusie/colib): [MIT License](Source/3rdParty/colib/LICENSE)
- [dragonBones](https://github.com/DragonBones/DragonBonesCPP): [MIT License](Source/3rdParty/dragonBones/LICENSE)
- [fmt](https://github.com/fmtlib/fmt): [MIT License](Source/3rdParty/fmt/LICENSE.rst)
- font ([bgfx-font](https://github.com/bkaradzic/bgfx/tree/master/examples/common/font)): [BSD-2 License](Source/3rdParty/bgfx/LICENSE)
- ghc ([gulrak/filesystem](https://github.com/gulrak/filesystem)): [MIT License](Source/3rdParty/ghc/LICENSE)
- [libogg](https://gitlab.xiph.org/xiph/ogg): [BSD-3-Clause License](Source/3rdParty/ogg/COPYING)
- [libtheora](https://gitlab.xiph.org/xiph/theora): [BSD-3-Clause License](Source/3rdParty/theora/COPYING)
- [libopenmpt](https://lib.openmpt.org/libopenmpt/): [BSD 3-Clause License](Source/3rdParty/libopenmpt/LICENSE)
- [imgui](https://github.com/ocornut/imgui): [MIT License](Source/3rdParty/imgui/LICENSE.txt)
- [Jolt Physics](https://github.com/jrouwe/JoltPhysics): [MIT License](Source/3rdParty/JoltPhysics/LICENSE)
- [implot](https://github.com/epezent/implot): [MIT License](Source/3rdParty/implot/LICENSE)
- [lodepng](https://github.com/lvandeve/lodepng): [zlib License](Source/3rdParty/lodepng/LICENSE)
- [LOVE](https://github.com/love2d/love): [zlib and bundled third-party licenses](Source/3rdParty/Love/license.txt)
- [Box2D 2.3.2, LOVE-modified](https://github.com/love2d/love/tree/11.5/src/libraries/Box2D): [zlib License](Source/3rdParty/Love/src/libraries/Box2D/Common/b2Settings.h)
- [Lua](https://github.com/lua/lua): [MIT License](Source/3rdParty/Lua/LICENSE)
- [LuaSocket](https://github.com/lunarmodules/luasocket): [MIT License](Source/3rdParty/LuaSocket/LICENSE)
- ml ([MachineLearning-DecisionTree](https://github.com/PiggyGaGa/MachineLearning-DecisionTree)): [BSD-2 License](Source/3rdParty/ml/LICENSE)
- [nanovg](https://github.com/memononen/nanovg): [zlib License](Source/3rdParty/nanovg/LICENSE.txt)
- [playrho](https://github.com/louis-langholtz/PlayRho): [zlib License](Source/3rdParty/playrho/LICENSE.txt)
- [rapidjson](https://github.com/Tencent/rapidjson): [MIT License](Source/3rdParty/rapidjson/license.txt)
- [SDL2](https://github.com/libsdl-org/SDL/tree/SDL2): [zlib License](Source/3rdParty/SDL2/COPYING.txt)
- silly: [Apache License 2.0](Source/3rdParty/silly/LICENSE)
- [soloud](https://github.com/jarikomppa/soloud): [zlib License](Source/3rdParty/soloud/LICENSE)
- [spine](https://github.com/EsotericSoftware/spine-runtimes): [Spine Runtimes License](Source/3rdParty/spine/LICENSE)
- [sqlite](https://github.com/sqlite/sqlite): [SQLite Public Domain License](Source/3rdParty/sqlite/LICENSE.md)
- [sqliteCpp](https://github.com/SRombauts/SQLiteCpp): [MIT License](Source/3rdParty/sqlite/sqliteCpp/LICENSE)
- [nothings/stb](https://github.com/nothings/stb): [MIT License](Source/3rdParty/stb/LICENSE)
- [tinyxml2](https://github.com/leethomason/tinyxml2): [zlib License](Source/3rdParty/tinyxml2/LICENSE.txt)
- [TIC-80](https://github.com/nesbox/TIC-80): [MIT License](Source/3rdParty/tic80/LICENSE)
- [wasm3](https://github.com/wasm3/wasm3): [MIT License](Source/3rdParty/wasm3/LICENSE)
- [Yard](https://sourceforge.net/projects/yard-parser): [Public Domain](https://sourceforge.net/projects/yard-parser)
- [YueScript](https://github.com/ippclub/YueScript): [MIT License](Source/3rdParty/yuescript/LICENSE)
- [richgel999/miniz](https://github.com/richgel999/miniz): [MIT License](Source/3rdParty/Zip/LICENSE-miniz)
- [zlib](https://www.zlib.net): [zlib License](Source/3rdParty/Zip/zlib/LICENSE)
- [concurrentqueue](https://github.com/cameron314/concurrentqueue): [BSD-2 License](Source/3rdParty/Other/LICENSE-concurrentqueue)
- [utf8](http://bjoern.hoehrmann.de/utf-8/decoder/dfa): [MIT License](http://bjoern.hoehrmann.de/utf-8/decoder/dfa)
- [septbr/xlsxtext](https://github.com/septbr/xlsxtext): [MIT License](Source/3rdParty/Other/LICENSE-xlsxtext)
- [timniederhausen/rapidxml](https://github.com/timniederhausen/rapidxml): [MIT License](Source/3rdParty/Other/LICENSE-rapidxml)
- ZipUtils([Cocos2d-x](https://github.com/cocos2d/cocos2d-x/tree/v2/cocos2dx/support/zip_support)): [MIT License](Source/3rdParty/Zip/LICENSE-ZipUtils)
- [AcfDelegate](https://www.codeproject.com/articles/11464/yet-another-c-style-delegate-class-in-standard-c): [AcfDelegate License](Source/3rdParty/Other/LICENSE-AcfDelegate)
- [teal-language](https://github.com/teal-language/tl): [MIT License](Source/Lua/Builtin/LICENSE-tl)
- [CodeWire](https://github.com/ayushk7/CodeWire): [MIT License](Tools/dora-dora/public/code-wire/LICENSE)
- [YarnClassic](https://github.com/blurymind/YarnClassic): [MIT License](Tools/dora-dora/src/3rdParty/YarnEditor/LICENSE.md)
- [LuLPeg](https://github.com/pygy/LuLPeg): [The Romantic WTF Public License](Tools/RustWasmGen/LICENSE-lulpeg)
- [deno_std](https://github.com/denoland/deno_std): [MIT License](Tools/dora-dora/src/3rdParty/LICENSE-deno)
- [monaco-editor-auto-typings](https://github.com/lukasbach/monaco-editor-auto-typings): [MIT License](Tools/dora-dora/src/3rdParty/monaco-editor-auto-typings/LICENSE)
- [TypeScriptToLua](https://github.com/TypeScriptToLua/TypeScriptToLua): [MIT License](Tools/dora-dora/src/3rdParty/tstl/LICENSE)
- [yoga](https://github.com/facebook/yoga): [MIT License](Source/3rdParty/yoga/LICENSE)
- [Effekseer](https://github.com/effekseer/Effekseer): [MIT License](Source/3rdParty/Effekseer/LICENSE)
- [efkbgfx](https://github.com/cloudwu/efkbgfx): [MIT License](Source/3rdParty/Effekseer/LICENSE-efkbgfx)
- [ktm](https://github.com/YGXXD/ktm): [MIT License](Source/3rdParty/ktm/LICENSE)
- [pugixml](https://github.com/zeux/pugixml): [MIT License](Source/3rdParty/tmxlite/detail/LICENSE-pugixml)
- [tmxlite](https://github.com/fallahn/tmxlite): [zlib License](Source/3rdParty/tmxlite/LICENSE)
- [prism](https://github.com/PrismJS/prism): [MIT License](Tools/dora-dora/src/languages/LICENSE-prism)
- [konva](https://github.com/konvajs/konva): [MIT License](Tools/dora-dora/public/code-wire/javascript/Dependencies/Konva/LICENSE)
- [spdlog](https://github.com/gabime/spdlog): [MIT License](Source/3rdParty/spdlog/LICENSE)
- [tiny-regex-c](https://github.com/kokke/tiny-regex-c): [Public Domain](Source/3rdParty/tiny-regex-c/LICENSE)
- [xrt](https://github.com/xywhsoft/xrt): [MIT License](Source/3rdParty/xrt/LICENSE)



## All in One

[License Texts](Assets/LICENSES)
