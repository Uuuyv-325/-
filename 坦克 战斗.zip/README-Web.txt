Web (HTML)

完整解压 ZIP 后，双击根目录 index.html 即可启动，无需 HTTP Server。请保留所有配套文件，使用支持 WebAssembly 的现代浏览器。
也可将整个目录部署到静态网站。资源编码为本地 JavaScript，启动时读入内存；包体积会增加，不适合超大资源项目。

Extract the entire ZIP and open index.html directly; no HTTP server is required. Keep all accompanying files. A modern WebAssembly-capable browser is required. The directory can also be hosted on a static website. Assets are encoded as local JavaScript and loaded into memory at startup, increasing package size.
